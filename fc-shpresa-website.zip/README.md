# FC Shpresa — Website + Paneli i Stafit

Faqe interneti për FC Shpresa: pjesa publike (skuadra, ndeshjet, lajme, galeria, kontakt) + paneli i administrimit për stafin, i lidhur me një bazë të dhënash Supabase (Postgres). Është një aplikacion web (React), jo një aplikacion i instalueshëm — hapet nga çdo shfletues, në telefon, tablet apo kompjuter.

## 1. Krijo projektin Supabase (baza e të dhënave)

1. Shko te [supabase.com](https://supabase.com) → **New project**. Zgjidh një emër, fjalëkalim databaze, dhe rajon (p.sh. Frankfurt, më afër Shqipërisë).
2. Kur projekti të jetë gati, shko te **SQL Editor** → **New query**, ngjit gjithë përmbajtjen e skedarit [`supabase/schema.sql`](supabase/schema.sql) nga ky projekt, dhe kliko **Run**. Kjo krijon të gjitha tabelat, rregullat e sigurisë (RLS), dhe bucket-in "media" për foto.
3. Shko te **Authentication → Users → Add user** dhe krijo një përdorues (email + fjalëkalim) për veten — ky është llogaria me të cilën do të hysh në panelin e adminit te `/admin/login`.
4. Shko te **Project Settings → API** dhe kopjo:
   - **Project URL**
   - **anon public key**

## 2. Konfiguro projektin lokalisht

1. Instalo [Node.js](https://nodejs.org) (versioni 18+) nëse nuk e ke.
2. Në terminal, brenda këtij folderi:
   ```
   npm install
   ```
3. Kopjo `.env.example` në një skedar të ri `.env` dhe plotëso me vlerat nga Supabase (hapi 1.4):
   ```
   VITE_SUPABASE_URL=https://xxxxxxxxxxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=xxxxxxxxxxxxxxxxxxxxx
   ```
4. Provo lokalisht:
   ```
   npm run dev
   ```
   Faqja hapet te `http://localhost:5173`. Paneli i stafit: `http://localhost:5173/admin/login`.

## 3. Publikoje faqen (që të hapet nga çdo pajisje, jo vetëm nga kompjuteri yt)

Mënyra më e thjeshtë falas: **Vercel** ose **Netlify**.

### Me Vercel
1. Ngarko këtë folder si repository në GitHub.
2. Shko te [vercel.com](https://vercel.com) → **Add New Project** → zgjidh repository-n.
3. Te **Environment Variables**, shto `VITE_SUPABASE_URL` dhe `VITE_SUPABASE_ANON_KEY` me të njëjtat vlera nga `.env`.
4. Kliko **Deploy**. Pas pak minutash merr një adresë si `fc-shpresa.vercel.app`, e hapshme nga çdo telefon, tablet apo kompjuter, kudo në botë.

### Me Netlify
Njësoj: lidh repository-n, vendos të njëjtat variabla mjedisi (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`), build command `npm run build`, publish directory `dist`.

## 4. Si menaxhohet përmbajtja

Hyr te `/admin/login` me emailin/fjalëkalimin që krijove në hapin 1.3. Nga aty mund të:
- shtosh/ndryshosh/fshish **lojtarë** (me numër fanellë dhe foto),
- **stafin teknik**,
- **ndeshjet** (të ardhshme dhe rezultatet),
- **klasifikimin** (tabelën e ligës — shëno rreshtin e FC Shpresa si "Është FC Shpresa: Po" që të dallohet në tabelë),
- **lajme** (me imazh kryesor dhe tekst),
- **foto** dhe **video** (video-t shtohen si lidhje YouTube dhe shfaqen si player i integruar te faqja Media),
- **cilësimet** e faqes (emri, viti i themelimit, përshkrimi, misioni, historiku, kontakti, Facebook/Instagram).

Çdo ndryshim që bën në panel shfaqet menjëherë në faqen publike, në çdo pajisje — sepse të dhënat ruhen në Supabase, jo në një skedar lokal.

## Faqet publike

Ballina · Akademia (rreth nesh + historiku) · Skuadra · Klasifikimi · Ndeshjet · Media (foto + video) · Lajme · Kontakt.

Stema zyrtare e klubit (`public/logo.jpg`) përdoret në header, në footer dhe në faqen e Akademisë. Për ta ndryshuar, zëvendëso skedarin `public/logo.jpg` me një tjetër (mbaje të njëjtin emër, ose ndrysho referencat në `src/components/Header.jsx` dhe `src/pages/Home.jsx`/`Academy.jsx`).

## Struktura e projektit

```
src/
  pages/        faqet publike (Ballina, Skuadra, Ndeshjet, Lajme, Galeria, Kontakt)
  admin/        paneli i stafit (login + CRUD për çdo tabelë)
  components/   header, footer, layout i përbashkët
  lib/          lidhja me Supabase
  context/      gjendja e identifikimit (login/logout)
supabase/
  schema.sql    skema e plotë e bazës së të dhënave + rregullat e sigurisë
```

## Shënime sigurie

- Vizitorët e zakonshëm mund vetëm të **lexojnë** të dhënat (skuadër, ndeshje, lajme, galeri) — asnjë vizitor nuk mund të ndryshojë asgjë pa hyrë me llogari stafi.
- Vetëm përdoruesit e krijuar te **Authentication → Users** në Supabase mund të hyjnë te `/admin` dhe të bëjnë ndryshime.
- Mos e ndaj `.env` skedarin publikisht (p.sh. mos e ngarko në një repository publik pa `.gitignore` — Vite e krijon këtë automatikisht).
