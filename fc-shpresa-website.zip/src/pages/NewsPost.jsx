import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';

export default function NewsPost() {
  const { slug } = useParams();
  const [post, setPost] = useState(undefined);

  useEffect(() => {
    supabase
      .from('news')
      .select('*')
      .eq('slug', slug)
      .maybeSingle()
      .then(({ data }) => setPost(data ?? null));
  }, [slug]);

  if (post === undefined) return null;

  if (post === null) {
    return (
      <div className="container" style={{ padding: '64px 0' }}>
        <p>Ky lajm nuk u gjet.</p>
        <Link to="/lajme" className="btn btn-outline" style={{ marginTop: 16 }}>Kthehu te lajmet</Link>
      </div>
    );
  }

  return (
    <article className="container" style={{ padding: '64px 0 80px', maxWidth: 720 }}>
      <Link to="/lajme" style={{ color: 'var(--text-dim)', fontSize: 14 }}>← Lajme</Link>
      <h1 style={{ fontSize: 34, marginTop: 16 }}>{post.title}</h1>
      <p style={{ color: 'var(--text-dim)', fontSize: 14, marginTop: 8 }}>
        {new Date(post.published_at).toLocaleDateString('sq-AL')} {post.author ? `· ${post.author}` : ''}
      </p>
      {post.cover_image_url && (
        <img src={post.cover_image_url} alt="" style={{ width: '100%', borderRadius: 6, marginTop: 24 }} />
      )}
      <div style={{ marginTop: 24, fontSize: 16, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>
        {post.content}
      </div>
    </article>
  );
}
