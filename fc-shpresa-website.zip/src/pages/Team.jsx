import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function Team() {
  const [players, setPlayers] = useState([]);
  const [staff, setStaff] = useState([]);

  useEffect(() => {
    supabase
      .from('players')
      .select('*')
      .order('jersey_number', { ascending: true })
      .then(({ data }) => setPlayers(data ?? []));

    supabase
      .from('staff')
      .select('*')
      .then(({ data }) => setStaff(data ?? []));
  }, []);

  return (
    <div className="container" style={{ padding: '64px 0 80px' }}>
      <h1 style={{ fontSize: 36, marginBottom: 8 }}>Skuadra</h1>
      <p style={{ color: 'var(--text-dim)', marginBottom: 40 }}>Lojtarët e regjistruar në ekipin aktual.</p>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          gap: 20,
        }}
      >
        {players.map((p) => (
          <div
            key={p.id}
            style={{
              border: '1px solid var(--line)',
              borderRadius: 6,
              background: 'var(--bg-card)',
              overflow: 'hidden',
            }}
          >
            <div style={{ aspectRatio: '3 / 4', background: 'var(--bg-elevated)', position: 'relative' }}>
              {p.photo_url ? (
                <img src={p.photo_url} alt={p.full_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text-dim)', fontFamily: 'var(--font-display)', fontSize: 48 }}>
                  {p.jersey_number}
                </div>
              )}
              <span
                style={{
                  position: 'absolute',
                  top: 8,
                  left: 8,
                  background: 'var(--gold)',
                  color: '#14100a',
                  fontFamily: 'var(--font-display)',
                  fontSize: 14,
                  padding: '2px 8px',
                  borderRadius: 3,
                }}
              >
                {p.jersey_number}
              </span>
            </div>
            <div style={{ padding: 14 }}>
              <p style={{ fontFamily: 'var(--font-display)', fontSize: 16 }}>{p.full_name}</p>
              <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 4 }}>{p.position}</p>
            </div>
          </div>
        ))}
      </div>

      {staff.length > 0 && (
        <>
          <h2 style={{ fontSize: 24, margin: '56px 0 24px' }}>Stafi teknik</h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
              gap: 20,
            }}
          >
            {staff.map((s) => (
              <div key={s.id} style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', overflow: 'hidden', background: 'var(--bg-card)', flexShrink: 0 }}>
                  {s.photo_url && <img src={s.photo_url} alt={s.full_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                </div>
                <div>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: 15 }}>{s.full_name}</p>
                  <p style={{ color: 'var(--text-dim)', fontSize: 13 }}>{s.role}</p>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
