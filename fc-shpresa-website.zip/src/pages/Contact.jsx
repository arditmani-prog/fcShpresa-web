import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function Contact() {
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    supabase.from('site_settings').select('*').limit(1).maybeSingle().then(({ data }) => setSettings(data));
  }, []);

  return (
    <div className="container" style={{ padding: '64px 0 80px', maxWidth: 560 }}>
      <h1 style={{ fontSize: 36, marginBottom: 24 }}>Kontakt</h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, fontSize: 16 }}>
        {settings?.address && (
          <div>
            <p style={{ color: 'var(--text-dim)', fontSize: 13 }}>Adresa</p>
            <p>{settings.address}</p>
          </div>
        )}
        {settings?.contact_phone && (
          <div>
            <p style={{ color: 'var(--text-dim)', fontSize: 13 }}>Telefon</p>
            <a href={`tel:${settings.contact_phone}`}>{settings.contact_phone}</a>
          </div>
        )}
        {settings?.contact_email && (
          <div>
            <p style={{ color: 'var(--text-dim)', fontSize: 13 }}>Email</p>
            <a href={`mailto:${settings.contact_email}`}>{settings.contact_email}</a>
          </div>
        )}
        {(settings?.facebook_url || settings?.instagram_url) && (
          <div>
            <p style={{ color: 'var(--text-dim)', fontSize: 13 }}>Rrjetet sociale</p>
            <div style={{ display: 'flex', gap: 16, marginTop: 4 }}>
              {settings.facebook_url && (
                <a href={settings.facebook_url} target="_blank" rel="noreferrer">Facebook</a>
              )}
              {settings.instagram_url && (
                <a href={settings.instagram_url} target="_blank" rel="noreferrer">Instagram</a>
              )}
            </div>
          </div>
        )}
        {!settings && <p style={{ color: 'var(--text-dim)' }}>Të dhënat e kontaktit do të shtohen së shpejti.</p>}
      </div>
    </div>
  );
}
