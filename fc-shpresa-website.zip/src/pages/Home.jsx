import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';
import PitchDivider from '../components/PitchDivider';

export default function Home() {
  const [nextMatch, setNextMatch] = useState(null);
  const [news, setNews] = useState([]);
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    supabase
      .from('matches')
      .select('*')
      .gte('match_date', new Date().toISOString())
      .order('match_date', { ascending: true })
      .limit(1)
      .then(({ data }) => setNextMatch(data?.[0] ?? null));

    supabase
      .from('news')
      .select('*')
      .order('published_at', { ascending: false })
      .limit(3)
      .then(({ data }) => setNews(data ?? []));

    supabase
      .from('site_settings')
      .select('*')
      .limit(1)
      .maybeSingle()
      .then(({ data }) => setSettings(data));
  }, []);

  return (
    <div>
      <section
        style={{
          padding: '96px 0 64px',
          background:
            'radial-gradient(ellipse 900px 400px at 50% -10%, rgba(212,166,74,0.12), transparent)',
        }}
      >
        <div className="container" style={{ display: 'flex', gap: 40, alignItems: 'center', flexWrap: 'wrap' }}>
          <img
            src="/logo.jpg"
            alt="Stema FC Shpresa"
            style={{ width: 140, height: 140, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }}
          />
          <div style={{ flex: 1, minWidth: 280 }}>
            <p style={{ color: 'var(--gold)', fontFamily: 'var(--font-display)', fontSize: 15, marginBottom: 12 }}>
              Akademia Shpresa{settings?.founded_year ? ` · ${settings.founded_year}` : ''}
            </p>
            <h1 style={{ fontSize: 'clamp(40px, 8vw, 76px)', lineHeight: 1.02, maxWidth: 780 }}>
              {settings?.club_name || 'FC Shpresa'}
            </h1>
            <p style={{ marginTop: 20, maxWidth: 560, color: 'var(--text-dim)', fontSize: 17 }}>
              {settings?.description ||
                'Akademi futbolli e themeluar mbi punën me brezat e rinj, disiplinën dhe dashurinë për lojën.'}
            </p>
            <div style={{ marginTop: 32, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <Link to="/skuadra" className="btn btn-primary">Shiko skuadrën</Link>
              <Link to="/ndeshjet" className="btn btn-outline">Ndeshjet</Link>
            </div>
          </div>
        </div>
      </section>

      <PitchDivider />

      {nextMatch && (
        <section className="container" style={{ padding: '48px 0' }}>
          <h2 style={{ fontSize: 22, marginBottom: 20 }}>Ndeshja e ardhshme</h2>
          <div
            style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--line)',
              borderRadius: 6,
              padding: 24,
              display: 'flex',
              flexWrap: 'wrap',
              justifyContent: 'space-between',
              gap: 12,
            }}
          >
            <div>
              <p style={{ fontFamily: 'var(--font-display)', fontSize: 20 }}>
                {nextMatch.home_away === 'home' ? 'FC Shpresa' : nextMatch.opponent} vs{' '}
                {nextMatch.home_away === 'home' ? nextMatch.opponent : 'FC Shpresa'}
              </p>
              <p style={{ color: 'var(--text-dim)', marginTop: 6, fontSize: 14 }}>
                {nextMatch.competition} · {nextMatch.location}
              </p>
            </div>
            <p style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--gold)' }}>
              {new Date(nextMatch.match_date).toLocaleString('sq-AL', {
                dateStyle: 'medium',
                timeStyle: 'short',
              })}
            </p>
          </div>
        </section>
      )}

      {news.length > 0 && (
        <section className="container" style={{ padding: '32px 0 80px' }}>
          <h2 style={{ fontSize: 22, marginBottom: 20 }}>Lajmet e fundit</h2>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
              gap: 20,
            }}
          >
            {news.map((n) => (
              <Link
                key={n.id}
                to={`/lajme/${n.slug}`}
                style={{
                  border: '1px solid var(--line)',
                  borderRadius: 6,
                  overflow: 'hidden',
                  background: 'var(--bg-card)',
                }}
              >
                {n.cover_image_url && (
                  <img src={n.cover_image_url} alt="" style={{ width: '100%', height: 140, objectFit: 'cover' }} />
                )}
                <div style={{ padding: 16 }}>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: 17 }}>{n.title}</p>
                  <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 8 }}>
                    {new Date(n.published_at).toLocaleDateString('sq-AL')}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
