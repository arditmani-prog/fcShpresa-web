import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';

export default function News() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    supabase
      .from('news')
      .select('*')
      .order('published_at', { ascending: false })
      .then(({ data }) => setNews(data ?? []));
  }, []);

  return (
    <div className="container" style={{ padding: '64px 0 80px' }}>
      <h1 style={{ fontSize: 36, marginBottom: 40 }}>Lajme</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 24 }}>
        {news.map((n) => (
          <Link
            key={n.id}
            to={`/lajme/${n.slug}`}
            style={{
              border: '1px solid var(--line)',
              borderRadius: 6,
              overflow: 'hidden',
              background: 'var(--bg-card)',
            }}
          >
            {n.cover_image_url && (
              <img src={n.cover_image_url} alt="" style={{ width: '100%', height: 160, objectFit: 'cover' }} />
            )}
            <div style={{ padding: 18 }}>
              <p style={{ fontFamily: 'var(--font-display)', fontSize: 18 }}>{n.title}</p>
              <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 8 }}>
                {new Date(n.published_at).toLocaleDateString('sq-AL')}
              </p>
            </div>
          </Link>
        ))}
        {news.length === 0 && <p style={{ color: 'var(--text-dim)' }}>Nuk ka lajme të publikuara ende.</p>}
      </div>
    </div>
  );
}
