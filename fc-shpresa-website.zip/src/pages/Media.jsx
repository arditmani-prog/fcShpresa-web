import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { toYouTubeEmbed } from '../lib/video';

export default function Media() {
  const [tab, setTab] = useState('foto');
  const [photos, setPhotos] = useState([]);
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    supabase
      .from('gallery')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => setPhotos(data ?? []));

    supabase
      .from('videos')
      .select('*')
      .order('published_at', { ascending: false })
      .then(({ data }) => setVideos(data ?? []));
  }, []);

  return (
    <div className="container" style={{ padding: '64px 0 80px' }}>
      <h1 style={{ fontSize: 36, marginBottom: 8 }}>Media</h1>
      <p style={{ color: 'var(--text-dim)', marginBottom: 32 }}>Magazina e fotove dhe videove të akademisë.</p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 32, borderBottom: '1px solid var(--line)' }}>
        {[
          { key: 'foto', label: 'Foto' },
          { key: 'video', label: 'Video' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={{
              background: 'none',
              border: 'none',
              padding: '10px 18px',
              fontFamily: 'var(--font-display)',
              fontSize: 15,
              cursor: 'pointer',
              color: tab === t.key ? 'var(--gold)' : 'var(--text-dim)',
              borderBottom: tab === t.key ? '2px solid var(--gold)' : '2px solid transparent',
              marginBottom: -1,
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'foto' ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 12 }}>
          {photos.map((p) => (
            <figure key={p.id} style={{ margin: 0, borderRadius: 6, overflow: 'hidden', border: '1px solid var(--line)' }}>
              <img src={p.image_url} alt={p.caption || ''} style={{ width: '100%', aspectRatio: '4 / 3', objectFit: 'cover' }} />
              {p.caption && (
                <figcaption style={{ padding: '8px 12px', fontSize: 13, color: 'var(--text-dim)' }}>{p.caption}</figcaption>
              )}
            </figure>
          ))}
          {photos.length === 0 && <p style={{ color: 'var(--text-dim)' }}>Nuk ka foto ende.</p>}
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 24 }}>
          {videos.map((v) => {
            const embed = toYouTubeEmbed(v.video_url);
            return (
              <div key={v.id} style={{ border: '1px solid var(--line)', borderRadius: 6, overflow: 'hidden', background: 'var(--bg-card)' }}>
                {embed ? (
                  <div style={{ position: 'relative', paddingTop: '56.25%' }}>
                    <iframe
                      src={embed}
                      title={v.title}
                      allowFullScreen
                      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 0 }}
                    />
                  </div>
                ) : (
                  <a href={v.video_url} target="_blank" rel="noreferrer">
                    {v.thumbnail_url && <img src={v.thumbnail_url} alt="" style={{ width: '100%', aspectRatio: '16 / 9', objectFit: 'cover' }} />}
                  </a>
                )}
                <div style={{ padding: 14 }}>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: 16 }}>{v.title}</p>
                  {v.description && <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 6 }}>{v.description}</p>}
                </div>
              </div>
            );
          })}
          {videos.length === 0 && <p style={{ color: 'var(--text-dim)' }}>Nuk ka video ende.</p>}
        </div>
      )}
    </div>
  );
}
