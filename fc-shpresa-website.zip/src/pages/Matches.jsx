import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

function MatchRow({ m }) {
  const played = m.status === 'played';
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: 12,
        padding: '16px 20px',
        border: '1px solid var(--line)',
        borderRadius: 6,
        background: 'var(--bg-card)',
        flexWrap: 'wrap',
      }}
    >
      <div>
        <p style={{ fontFamily: 'var(--font-display)', fontSize: 17 }}>
          {m.home_away === 'home' ? 'FC Shpresa' : m.opponent} vs{' '}
          {m.home_away === 'home' ? m.opponent : 'FC Shpresa'}
        </p>
        <p style={{ color: 'var(--text-dim)', fontSize: 13, marginTop: 4 }}>
          {m.competition} · {m.location}
        </p>
      </div>
      {played ? (
        <p style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: 'var(--gold)' }}>
          {m.score_home} – {m.score_away}
        </p>
      ) : (
        <p style={{ fontFamily: 'var(--font-display)', fontSize: 15, color: 'var(--text-dim)' }}>
          {new Date(m.match_date).toLocaleString('sq-AL', { dateStyle: 'medium', timeStyle: 'short' })}
        </p>
      )}
    </div>
  );
}

export default function Matches() {
  const [upcoming, setUpcoming] = useState([]);
  const [past, setPast] = useState([]);

  useEffect(() => {
    const now = new Date().toISOString();
    supabase
      .from('matches')
      .select('*')
      .gte('match_date', now)
      .order('match_date', { ascending: true })
      .then(({ data }) => setUpcoming(data ?? []));

    supabase
      .from('matches')
      .select('*')
      .lt('match_date', now)
      .order('match_date', { ascending: false })
      .then(({ data }) => setPast(data ?? []));
  }, []);

  return (
    <div className="container" style={{ padding: '64px 0 80px' }}>
      <h1 style={{ fontSize: 36, marginBottom: 40 }}>Ndeshjet</h1>

      <h2 style={{ fontSize: 20, marginBottom: 16, color: 'var(--text-dim)' }}>Të ardhshme</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 48 }}>
        {upcoming.length === 0 && <p style={{ color: 'var(--text-dim)' }}>Nuk ka ndeshje të planifikuara.</p>}
        {upcoming.map((m) => (
          <MatchRow key={m.id} m={m} />
        ))}
      </div>

      <h2 style={{ fontSize: 20, marginBottom: 16, color: 'var(--text-dim)' }}>Rezultatet e fundit</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {past.length === 0 && <p style={{ color: 'var(--text-dim)' }}>Nuk ka rezultate ende.</p>}
        {past.map((m) => (
          <MatchRow key={m.id} m={m} />
        ))}
      </div>
    </div>
  );
}
