import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import PitchDivider from '../components/PitchDivider';

export default function Academy() {
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    supabase.from('site_settings').select('*').limit(1).maybeSingle().then(({ data }) => setSettings(data));
  }, []);

  return (
    <div>
      <section className="container" style={{ padding: '64px 0 40px' }}>
        <div style={{ display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap' }}>
          <img
            src="/logo.jpg"
            alt="Stema FC Shpresa"
            style={{ width: 96, height: 96, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }}
          />
          <div>
            <h1 style={{ fontSize: 34 }}>{settings?.club_name || 'FC Shpresa'}</h1>
            {settings?.founded_year && (
              <p style={{ color: 'var(--gold)', fontFamily: 'var(--font-display)', fontSize: 15, marginTop: 6 }}>
                Themeluar në {settings.founded_year}
              </p>
            )}
          </div>
        </div>
        <p style={{ marginTop: 24, maxWidth: 680, fontSize: 17, color: 'var(--text-dim)' }}>
          {settings?.description}
        </p>
      </section>

      <PitchDivider />

      {settings?.mission && (
        <section className="container" style={{ padding: '48px 0' }}>
          <h2 style={{ fontSize: 24, marginBottom: 16 }}>Misioni</h2>
          <p style={{ maxWidth: 680, fontSize: 16, lineHeight: 1.7, color: 'var(--text-dim)' }}>{settings.mission}</p>
        </section>
      )}

      {settings?.history && (
        <section className="container" style={{ padding: '16px 0 80px' }}>
          <h2 style={{ fontSize: 24, marginBottom: 16 }}>Historiku</h2>
          <p style={{ maxWidth: 680, fontSize: 16, lineHeight: 1.7, whiteSpace: 'pre-wrap', color: 'var(--text-dim)' }}>
            {settings.history}
          </p>
        </section>
      )}
    </div>
  );
}
