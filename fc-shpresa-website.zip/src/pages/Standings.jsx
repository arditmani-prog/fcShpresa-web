import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

const cols = [
  { key: 'played', label: 'L' },
  { key: 'won', label: 'F' },
  { key: 'drawn', label: 'B' },
  { key: 'lost', label: 'H' },
  { key: 'goals_for', label: 'GJ' },
  { key: 'goals_against', label: 'GP' },
  { key: 'points', label: 'Pikë' },
];

export default function Standings() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    supabase
      .from('standings')
      .select('*')
      .order('points', { ascending: false })
      .then(({ data }) => setRows(data ?? []));
  }, []);

  return (
    <div className="container" style={{ padding: '64px 0 80px' }}>
      <h1 style={{ fontSize: 36, marginBottom: 8 }}>Klasifikimi</h1>
      <p style={{ color: 'var(--text-dim)', marginBottom: 40 }}>
        L = Luajtur, F = Fituar, B = Barazim, H = Humbur, GJ = Gola të shënuar, GP = Gola të pësuar.
      </p>

      <div style={{ overflowX: 'auto' }}>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Ekipi</th>
              {cols.map((c) => (
                <th key={c.key} style={{ textAlign: 'center' }}>
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr
                key={r.id}
                style={r.is_own_team ? { background: 'rgba(212,166,74,0.08)' } : undefined}
              >
                <td style={{ color: 'var(--text-dim)' }}>{i + 1}</td>
                <td style={{ fontFamily: 'var(--font-display)', color: r.is_own_team ? 'var(--gold)' : 'var(--text)' }}>
                  {r.team_name}
                </td>
                {cols.map((c) => (
                  <td key={c.key} style={{ textAlign: 'center' }}>
                    {r[c.key]}
                  </td>
                ))}
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={9} style={{ color: 'var(--text-dim)' }}>
                  Klasifikimi nuk është azhurnuar ende.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
