import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

import PublicLayout from './components/PublicLayout';
import Home from './pages/Home';
import Academy from './pages/Academy';
import Team from './pages/Team';
import Standings from './pages/Standings';
import Matches from './pages/Matches';
import Media from './pages/Media';
import News from './pages/News';
import NewsPost from './pages/NewsPost';
import Contact from './pages/Contact';

import Login from './admin/Login';
import ProtectedRoute from './admin/ProtectedRoute';
import AdminLayout from './admin/AdminLayout';
import Dashboard from './admin/Dashboard';
import PlayersAdmin from './admin/PlayersAdmin';
import StaffAdmin from './admin/StaffAdmin';
import MatchesAdmin from './admin/MatchesAdmin';
import StandingsAdmin from './admin/StandingsAdmin';
import NewsAdmin from './admin/NewsAdmin';
import GalleryAdmin from './admin/GalleryAdmin';
import VideosAdmin from './admin/VideosAdmin';
import SettingsAdmin from './admin/SettingsAdmin';

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/akademia" element={<Academy />} />
          <Route path="/skuadra" element={<Team />} />
          <Route path="/klasifikimi" element={<Standings />} />
          <Route path="/ndeshjet" element={<Matches />} />
          <Route path="/media" element={<Media />} />
          <Route path="/lajme" element={<News />} />
          <Route path="/lajme/:slug" element={<NewsPost />} />
          <Route path="/kontakt" element={<Contact />} />
        </Route>

        <Route path="/admin/login" element={<Login />} />
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="lojtaret" element={<PlayersAdmin />} />
          <Route path="stafi" element={<StaffAdmin />} />
          <Route path="ndeshjet" element={<MatchesAdmin />} />
          <Route path="klasifikimi" element={<StandingsAdmin />} />
          <Route path="lajme" element={<NewsAdmin />} />
          <Route path="galeria" element={<GalleryAdmin />} />
          <Route path="video" element={<VideosAdmin />} />
          <Route path="cilesimet" element={<SettingsAdmin />} />
        </Route>
      </Routes>
    </AuthProvider>
  );
}
