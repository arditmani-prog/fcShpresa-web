export default function PitchDivider({ flip = false }) {
  return (
    <svg
      viewBox="0 0 1120 40"
      preserveAspectRatio="none"
      style={{
        width: '100%',
        height: 40,
        display: 'block',
        transform: flip ? 'scaleY(-1)' : 'none',
      }}
      aria-hidden="true"
    >
      <line x1="0" y1="1" x2="1120" y2="1" stroke="var(--line)" strokeWidth="1" />
      <path
        d="M 460 1 A 100 100 0 0 0 660 1"
        fill="none"
        stroke="var(--line)"
        strokeWidth="1"
      />
      <circle cx="560" cy="1" r="2.5" fill="var(--gold-dim)" />
    </svg>
  );
}
