import { useState } from 'react';
import { NavLink } from 'react-router-dom';

const links = [
  { to: '/', label: 'Ballina', end: true },
  { to: '/akademia', label: 'Akademia' },
  { to: '/skuadra', label: 'Skuadra' },
  { to: '/klasifikimi', label: 'Klasifikimi' },
  { to: '/ndeshjet', label: 'Ndeshjet' },
  { to: '/media', label: 'Media' },
  { to: '/lajme', label: 'Lajme' },
  { to: '/kontakt', label: 'Kontakt' },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header
      style={{
        borderBottom: '1px solid var(--line)',
        background: 'var(--bg-elevated)',
        position: 'sticky',
        top: 0,
        zIndex: 20,
      }}
    >
      <div
        className="container"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          height: 68,
        }}
      >
        <NavLink
          to="/"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            fontFamily: 'var(--font-display)',
            fontSize: 20,
            fontWeight: 700,
            letterSpacing: '0.02em',
            flexShrink: 0,
          }}
        >
          <img
            src="/logo.jpg"
            alt="Stema FC Shpresa"
            style={{ height: 40, width: 40, objectFit: 'cover', borderRadius: '50%' }}
          />
          <span className="wordmark">FC SHPRESA</span>
        </NavLink>

        <nav className="desktop-nav" style={{ display: 'flex', gap: 20 }}>
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              style={({ isActive }) => ({
                fontFamily: 'var(--font-display)',
                fontSize: 14,
                letterSpacing: '0.02em',
                whiteSpace: 'nowrap',
                color: isActive ? 'var(--gold)' : 'var(--text-dim)',
              })}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <button
          onClick={() => setOpen((v) => !v)}
          className="mobile-toggle"
          aria-label="Hap menynë"
          aria-expanded={open}
          style={{
            display: 'none',
            background: 'none',
            border: '1px solid var(--line)',
            borderRadius: 4,
            width: 40,
            height: 40,
            color: 'var(--text)',
            flexShrink: 0,
          }}
        >
          {open ? '✕' : '☰'}
        </button>
      </div>

      {open && (
        <nav
          style={{
            borderTop: '1px solid var(--line)',
            display: 'flex',
            flexDirection: 'column',
            padding: '8px 24px 16px',
          }}
        >
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              onClick={() => setOpen(false)}
              style={({ isActive }) => ({
                fontFamily: 'var(--font-display)',
                fontSize: 16,
                padding: '10px 0',
                color: isActive ? 'var(--gold)' : 'var(--text-dim)',
              })}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
      )}

      <style>{`
        @media (max-width: 920px) {
          .desktop-nav { display: none !important; }
          .mobile-toggle { display: flex !important; align-items: center; justify-content: center; }
        }
        @media (max-width: 380px) {
          .wordmark { display: none; }
        }
      `}</style>
    </header>
  );
}
