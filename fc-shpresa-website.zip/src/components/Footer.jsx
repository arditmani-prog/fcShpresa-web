import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer
      style={{
        borderTop: '1px solid var(--line)',
        marginTop: 80,
        background: 'var(--bg-elevated)',
      }}
    >
      <div
        className="container"
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 16,
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '28px 24px',
          fontSize: 14,
          color: 'var(--text-dim)',
        }}
      >
        <span>FC Shpresa · Akademia e futbollit</span>
        <Link to="/admin/login" style={{ color: 'var(--text-dim)' }}>
          Hyrje stafi
        </Link>
      </div>
    </footer>
  );
}
