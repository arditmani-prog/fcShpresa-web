import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

/**
 * Generic CRUD screen for a single Supabase table.
 *
 * fields: [{ key, label, type: 'text'|'number'|'textarea'|'datetime'|'select'|'image', options?, required? }]
 */
export default function CrudTable({ title, table, fields, orderBy, orderAsc = true, bucket }) {
  const [rows, setRows] = useState([]);
  const [editing, setEditing] = useState(null); // row object or null
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    let query = supabase.from(table).select('*');
    if (orderBy) query = query.order(orderBy, { ascending: orderAsc });
    const { data, error } = await query;
    if (error) setError(error.message);
    setRows(data ?? []);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table]);

  const openNew = () => {
    setEditing({});
    setForm({});
    setError('');
  };

  const openEdit = (row) => {
    setEditing(row);
    setForm(row);
    setError('');
  };

  const closeForm = () => {
    setEditing(null);
    setForm({});
  };

  const handleChange = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
  };

  const handleUpload = async (key, file) => {
    if (!bucket || !file) return;
    setUploading(true);
    const path = `${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from(bucket).upload(path, file);
    if (uploadError) {
      setError(uploadError.message);
      setUploading(false);
      return;
    }
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    handleChange(key, data.publicUrl);
    setUploading(false);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const payload = { ...form };
    delete payload.id;
    delete payload.created_at;

    // Coerce values to the right JS type per field config before sending to Postgres.
    fields.forEach((f) => {
      if (!(f.key in payload)) return;
      const v = payload[f.key];
      if (f.type === 'number') {
        payload[f.key] = v === '' || v === null || v === undefined ? null : Number(v);
      } else if (f.type === 'boolean') {
        payload[f.key] = Boolean(v);
      }
    });

    const query = editing?.id
      ? supabase.from(table).update(payload).eq('id', editing.id)
      : supabase.from(table).insert(payload);

    const { error } = await query;
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    closeForm();
    load();
  };

  const handleDelete = async (row) => {
    if (!window.confirm('Të fshihet ky rresht?')) return;
    const { error } = await supabase.from(table).delete().eq('id', row.id);
    if (error) {
      setError(error.message);
      return;
    }
    load();
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 26 }}>{title}</h1>
        {!editing && (
          <button className="btn btn-primary" onClick={openNew}>
            + Shto
          </button>
        )}
      </div>

      {error && <p style={{ color: 'var(--red)', marginBottom: 16 }}>{error}</p>}

      {editing ? (
        <form
          onSubmit={handleSave}
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: 16,
            maxWidth: 480,
            background: 'var(--bg-card)',
            border: '1px solid var(--line)',
            borderRadius: 8,
            padding: 24,
          }}
        >
          {fields.map((f) => (
            <div className="field" key={f.key}>
              <label htmlFor={f.key}>{f.label}</label>
              {f.type === 'textarea' ? (
                <textarea
                  id={f.key}
                  rows={5}
                  value={form[f.key] ?? ''}
                  required={f.required}
                  onChange={(e) => handleChange(f.key, e.target.value)}
                />
              ) : f.type === 'boolean' ? (
                <input
                  id={f.key}
                  type="checkbox"
                  checked={Boolean(form[f.key])}
                  onChange={(e) => handleChange(f.key, e.target.checked)}
                  style={{ width: 20, height: 20, alignSelf: 'flex-start' }}
                />
              ) : f.type === 'select' ? (
                <select
                  id={f.key}
                  value={form[f.key] ?? ''}
                  required={f.required}
                  onChange={(e) => handleChange(f.key, e.target.value)}
                >
                  <option value="" disabled>
                    Zgjidh...
                  </option>
                  {f.options.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              ) : f.type === 'image' ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {form[f.key] && (
                    <img src={form[f.key]} alt="" style={{ width: 120, height: 120, objectFit: 'cover', borderRadius: 4 }} />
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleUpload(f.key, e.target.files?.[0])}
                  />
                  {uploading && <span style={{ fontSize: 13, color: 'var(--text-dim)' }}>Duke ngarkuar...</span>}
                </div>
              ) : (
                <input
                  id={f.key}
                  type={f.type === 'datetime' ? 'datetime-local' : f.type === 'number' ? 'number' : 'text'}
                  value={form[f.key] ?? ''}
                  required={f.required}
                  onChange={(e) => handleChange(f.key, e.target.value)}
                />
              )}
            </div>
          ))}

          <div style={{ display: 'flex', gap: 12 }}>
            <button type="submit" className="btn btn-primary" disabled={loading || uploading}>
              {loading ? 'Duke ruajtur...' : 'Ruaj'}
            </button>
            <button type="button" className="btn btn-outline" onClick={closeForm}>
              Anulo
            </button>
          </div>
        </form>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr>
                {fields.slice(0, 4).map((f) => (
                  <th key={f.key}>{f.label}</th>
                ))}
                <th></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  {fields.slice(0, 4).map((f) => (
                    <td key={f.key}>
                      {f.type === 'image' ? (
                        row[f.key] ? (
                          <img src={row[f.key]} alt="" style={{ width: 36, height: 36, objectFit: 'cover', borderRadius: 4 }} />
                        ) : (
                          '—'
                        )
                      ) : f.type === 'boolean' ? (
                        row[f.key] ? 'Po' : 'Jo'
                      ) : (
                        String(row[f.key] ?? '').slice(0, 60)
                      )}
                    </td>
                  ))}
                  <td style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                    <button className="btn btn-outline" onClick={() => openEdit(row)}>
                      Ndrysho
                    </button>
                    <button className="btn btn-outline" onClick={() => handleDelete(row)}>
                      Fshi
                    </button>
                  </td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={fields.length + 1} style={{ color: 'var(--text-dim)' }}>
                    Nuk ka të dhëna ende.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
