import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const from = location.state?.from?.pathname || '/admin';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      setError('Email ose fjalëkalim i pasaktë.');
      return;
    }
    navigate(from, { replace: true });
  };

  return (
    <div
      style={{
        minHeight: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
      }}
    >
      <form
        onSubmit={handleSubmit}
        style={{
          width: '100%',
          maxWidth: 380,
          background: 'var(--bg-card)',
          border: '1px solid var(--line)',
          borderRadius: 8,
          padding: 32,
          display: 'flex',
          flexDirection: 'column',
          gap: 18,
        }}
      >
        <h1 style={{ fontSize: 22, textAlign: 'center' }}>Paneli i Stafit</h1>
        <p style={{ textAlign: 'center', color: 'var(--text-dim)', fontSize: 14, marginTop: -8 }}>FC Shpresa</p>

        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="field">
          <label htmlFor="password">Fjalëkalimi</label>
          <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>

        {error && <p style={{ color: 'var(--red)', fontSize: 14 }}>{error}</p>}

        <button type="submit" className="btn btn-primary" disabled={loading} style={{ justifyContent: 'center' }}>
          {loading ? 'Duke hyrë...' : 'Hyr'}
        </button>
      </form>
    </div>
  );
}
