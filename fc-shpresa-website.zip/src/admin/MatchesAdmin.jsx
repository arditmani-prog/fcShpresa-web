import CrudTable from './CrudTable';

export default function MatchesAdmin() {
  return (
    <CrudTable
      title="Ndeshjet"
      table="matches"
      orderBy="match_date"
      orderAsc={false}
      fields={[
        { key: 'match_date', label: 'Data & ora', type: 'datetime', required: true },
        { key: 'opponent', label: 'Kundërshtari', type: 'text', required: true },
        {
          key: 'home_away',
          label: 'Vendi',
          type: 'select',
          required: true,
          options: [
            { value: 'home', label: 'Shtëpi' },
            { value: 'away', label: 'Trasferte' },
          ],
        },
        { key: 'location', label: 'Stadiumi/Vendndodhja', type: 'text' },
        { key: 'competition', label: 'Kompeticioni', type: 'text' },
        {
          key: 'status',
          label: 'Statusi',
          type: 'select',
          required: true,
          options: [
            { value: 'scheduled', label: 'E planifikuar' },
            { value: 'played', label: 'E luajtur' },
          ],
        },
        { key: 'score_home', label: 'Golat (shtëpi)', type: 'number' },
        { key: 'score_away', label: 'Golat (miku)', type: 'number' },
      ]}
    />
  );
}
