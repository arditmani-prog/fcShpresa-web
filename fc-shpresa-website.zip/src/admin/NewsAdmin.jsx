import CrudTable from './CrudTable';

export default function NewsAdmin() {
  return (
    <CrudTable
      title="Lajme"
      table="news"
      orderBy="published_at"
      orderAsc={false}
      bucket="media"
      fields={[
        { key: 'title', label: 'Titulli', type: 'text', required: true },
        { key: 'slug', label: 'Slug (p.sh. fitore-e-madhe)', type: 'text', required: true },
        { key: 'published_at', label: 'Data e publikimit', type: 'datetime', required: true },
        { key: 'author', label: 'Autori', type: 'text' },
        { key: 'cover_image_url', label: 'Foto kryesore', type: 'image' },
        { key: 'content', label: 'Përmbajtja', type: 'textarea', required: true },
      ]}
    />
  );
}
