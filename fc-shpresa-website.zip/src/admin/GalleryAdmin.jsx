import CrudTable from './CrudTable';

export default function GalleryAdmin() {
  return (
    <CrudTable
      title="Galeria"
      table="gallery"
      orderBy="created_at"
      orderAsc={false}
      bucket="media"
      fields={[
        { key: 'image_url', label: 'Imazhi', type: 'image', required: true },
        { key: 'caption', label: 'Përshkrimi', type: 'text' },
        { key: 'category', label: 'Kategoria', type: 'text' },
      ]}
    />
  );
}
