import CrudTable from './CrudTable';

export default function StaffAdmin() {
  return (
    <CrudTable
      title="Stafi teknik"
      table="staff"
      orderBy="full_name"
      bucket="media"
      fields={[
        { key: 'full_name', label: 'Emri i plotë', type: 'text', required: true },
        { key: 'role', label: 'Roli', type: 'text', required: true },
        { key: 'photo_url', label: 'Foto', type: 'image' },
        { key: 'bio', label: 'Biografi e shkurtër', type: 'textarea' },
      ]}
    />
  );
}
