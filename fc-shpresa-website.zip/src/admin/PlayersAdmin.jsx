import CrudTable from './CrudTable';

export default function PlayersAdmin() {
  return (
    <CrudTable
      title="Lojtarët"
      table="players"
      orderBy="jersey_number"
      bucket="media"
      fields={[
        { key: 'jersey_number', label: 'Numri', type: 'number', required: true },
        { key: 'full_name', label: 'Emri i plotë', type: 'text', required: true },
        { key: 'position', label: 'Pozicioni', type: 'text' },
        { key: 'birth_date', label: 'Datëlindja', type: 'text' },
        { key: 'photo_url', label: 'Foto', type: 'image' },
        { key: 'bio', label: 'Biografi e shkurtër', type: 'textarea' },
      ]}
    />
  );
}
