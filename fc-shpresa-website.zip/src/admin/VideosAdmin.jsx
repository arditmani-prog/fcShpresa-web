import CrudTable from './CrudTable';

export default function VideosAdmin() {
  return (
    <CrudTable
      title="Video"
      table="videos"
      orderBy="published_at"
      orderAsc={false}
      bucket="media"
      fields={[
        { key: 'title', label: 'Titulli', type: 'text', required: true },
        { key: 'video_url', label: 'Lidhja YouTube', type: 'text', required: true },
        { key: 'published_at', label: 'Data e publikimit', type: 'datetime', required: true },
        { key: 'thumbnail_url', label: 'Miniaturë (nëse s\u2019është YouTube)', type: 'image' },
        { key: 'description', label: 'Përshkrimi', type: 'textarea' },
      ]}
    />
  );
}
