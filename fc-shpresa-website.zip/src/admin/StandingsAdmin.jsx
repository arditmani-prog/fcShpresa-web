import CrudTable from './CrudTable';

export default function StandingsAdmin() {
  return (
    <CrudTable
      title="Klasifikimi"
      table="standings"
      orderBy="points"
      orderAsc={false}
      fields={[
        { key: 'team_name', label: 'Ekipi', type: 'text', required: true },
        { key: 'played', label: 'Luajtur', type: 'number' },
        { key: 'won', label: 'Fituar', type: 'number' },
        { key: 'drawn', label: 'Barazim', type: 'number' },
        { key: 'lost', label: 'Humbur', type: 'number' },
        { key: 'goals_for', label: 'Gola të shënuar', type: 'number' },
        { key: 'goals_against', label: 'Gola të pësuar', type: 'number' },
        { key: 'points', label: 'Pikë', type: 'number', required: true },
        { key: 'is_own_team', label: 'Është FC Shpresa?', type: 'boolean' },
      ]}
    />
  );
}
