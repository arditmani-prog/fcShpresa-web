import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const links = [
  { to: '/admin', label: 'Përmbledhje', end: true },
  { to: '/admin/lojtaret', label: 'Lojtarët' },
  { to: '/admin/stafi', label: 'Stafi' },
  { to: '/admin/ndeshjet', label: 'Ndeshjet' },
  { to: '/admin/klasifikimi', label: 'Klasifikimi' },
  { to: '/admin/lajme', label: 'Lajme' },
  { to: '/admin/galeria', label: 'Foto' },
  { to: '/admin/video', label: 'Video' },
  { to: '/admin/cilesimet', label: 'Cilësimet' },
];

export default function AdminLayout() {
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate('/admin/login');
  };

  return (
    <div style={{ display: 'flex', minHeight: '100%' }}>
      <aside
        style={{
          width: 220,
          flexShrink: 0,
          borderRight: '1px solid var(--line)',
          background: 'var(--bg-elevated)',
          padding: '24px 16px',
          display: 'flex',
          flexDirection: 'column',
          gap: 4,
        }}
      >
        <p style={{ fontFamily: 'var(--font-display)', fontSize: 18, padding: '0 8px 20px' }}>FC Shpresa</p>
        {links.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            end={l.end}
            style={({ isActive }) => ({
              padding: '10px 8px',
              borderRadius: 4,
              fontSize: 14,
              background: isActive ? 'var(--bg-card)' : 'transparent',
              color: isActive ? 'var(--gold)' : 'var(--text-dim)',
            })}
          >
            {l.label}
          </NavLink>
        ))}
        <button
          onClick={handleLogout}
          className="btn btn-outline"
          style={{ marginTop: 'auto', justifyContent: 'center' }}
        >
          Dil
        </button>
      </aside>
      <main style={{ flex: 1, padding: 32, overflowX: 'auto' }}>
        <Outlet />
      </main>
    </div>
  );
}
