import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function SettingsAdmin() {
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    supabase
      .from('site_settings')
      .select('*')
      .limit(1)
      .maybeSingle()
      .then(({ data }) => setForm(data || {}));
  }, []);

  const handleChange = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSaved(false);

    const payload = { ...form };
    if (payload.founded_year === '' || payload.founded_year === null || payload.founded_year === undefined) {
      payload.founded_year = null;
    } else {
      payload.founded_year = Number(payload.founded_year);
    }
    const query = payload.id
      ? supabase.from('site_settings').update(payload).eq('id', payload.id)
      : supabase.from('site_settings').insert(payload).select().single();

    const { data, error } = await query;
    setSaving(false);
    if (error) {
      setError(error.message);
      return;
    }
    if (data) setForm(data);
    setSaved(true);
  };

  if (form === null) return null;

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 24 }}>Cilësimet e faqes</h1>
      <form
        onSubmit={handleSave}
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
          maxWidth: 480,
          background: 'var(--bg-card)',
          border: '1px solid var(--line)',
          borderRadius: 8,
          padding: 24,
        }}
      >
        <div className="field">
          <label>Emri i klubit</label>
          <input value={form.club_name ?? ''} onChange={(e) => handleChange('club_name', e.target.value)} />
        </div>
        <div className="field">
          <label>Viti i themelimit</label>
          <input type="number" value={form.founded_year ?? ''} onChange={(e) => handleChange('founded_year', e.target.value)} />
        </div>
        <div className="field">
          <label>Përshkrimi (Ballina)</label>
          <textarea rows={4} value={form.description ?? ''} onChange={(e) => handleChange('description', e.target.value)} />
        </div>
        <div className="field">
          <label>Misioni</label>
          <textarea rows={3} value={form.mission ?? ''} onChange={(e) => handleChange('mission', e.target.value)} />
        </div>
        <div className="field">
          <label>Historiku i akademisë</label>
          <textarea rows={8} value={form.history ?? ''} onChange={(e) => handleChange('history', e.target.value)} />
        </div>
        <div className="field">
          <label>Email kontakti</label>
          <input value={form.contact_email ?? ''} onChange={(e) => handleChange('contact_email', e.target.value)} />
        </div>
        <div className="field">
          <label>Telefon kontakti</label>
          <input value={form.contact_phone ?? ''} onChange={(e) => handleChange('contact_phone', e.target.value)} />
        </div>
        <div className="field">
          <label>Adresa</label>
          <input value={form.address ?? ''} onChange={(e) => handleChange('address', e.target.value)} />
        </div>
        <div className="field">
          <label>Facebook (lidhja e plotë)</label>
          <input value={form.facebook_url ?? ''} onChange={(e) => handleChange('facebook_url', e.target.value)} />
        </div>
        <div className="field">
          <label>Instagram (lidhja e plotë)</label>
          <input value={form.instagram_url ?? ''} onChange={(e) => handleChange('instagram_url', e.target.value)} />
        </div>

        {error && <p style={{ color: 'var(--red)' }}>{error}</p>}
        {saved && <p style={{ color: 'var(--gold)' }}>U ruajt.</p>}

        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? 'Duke ruajtur...' : 'Ruaj ndryshimet'}
        </button>
      </form>
    </div>
  );
}
