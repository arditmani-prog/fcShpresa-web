import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

const cards = [
  { table: 'players', label: 'Lojtarë' },
  { table: 'staff', label: 'Staf' },
  { table: 'matches', label: 'Ndeshje' },
  { table: 'standings', label: 'Ekipe në klasifikim' },
  { table: 'news', label: 'Lajme' },
  { table: 'gallery', label: 'Foto' },
  { table: 'videos', label: 'Video' },
];

export default function Dashboard() {
  const [counts, setCounts] = useState({});

  useEffect(() => {
    cards.forEach(({ table }) => {
      supabase
        .from(table)
        .select('*', { count: 'exact', head: true })
        .then(({ count }) => setCounts((c) => ({ ...c, [table]: count ?? 0 })));
    });
  }, []);

  return (
    <div>
      <h1 style={{ fontSize: 26, marginBottom: 24 }}>Përmbledhje</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 16 }}>
        {cards.map((c) => (
          <div
            key={c.table}
            style={{
              border: '1px solid var(--line)',
              borderRadius: 8,
              background: 'var(--bg-card)',
              padding: 20,
            }}
          >
            <p style={{ fontFamily: 'var(--font-display)', fontSize: 32, color: 'var(--gold)' }}>
              {counts[c.table] ?? '–'}
            </p>
            <p style={{ color: 'var(--text-dim)', fontSize: 14, marginTop: 4 }}>{c.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
