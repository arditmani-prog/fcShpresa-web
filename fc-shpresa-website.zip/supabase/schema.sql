-- FC Shpresa — Supabase schema
-- Run this in your Supabase project's SQL editor (Project > SQL Editor > New query).

-- 0. MIGRIMI (vetëm nëse e ke ekzekutuar këtë skedar më parë, në një version
--    të mëparshëm të projektit) — shto kolonat/tabelat e reja pa prishur të
--    dhënat ekzistuese. Nëse ky është ekzekutimi i parë, këto komanda thjesht
--    nuk bëjnë asgjë (kolonat/tabelat krijohen normalisht më poshtë).

alter table if exists public.site_settings add column if not exists founded_year int;
alter table if exists public.site_settings add column if not exists history text;
alter table if exists public.site_settings add column if not exists mission text;
alter table if exists public.site_settings add column if not exists facebook_url text;
alter table if exists public.site_settings add column if not exists instagram_url text;

-- 1. TABLES ------------------------------------------------------------

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  jersey_number int not null,
  full_name text not null,
  position text,
  birth_date text,
  photo_url text,
  bio text,
  created_at timestamptz not null default now()
);

create table if not exists public.staff (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  role text not null,
  photo_url text,
  bio text,
  created_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  opponent text not null,
  match_date timestamptz not null,
  location text,
  home_away text not null check (home_away in ('home', 'away')),
  competition text,
  status text not null default 'scheduled' check (status in ('scheduled', 'played')),
  score_home int,
  score_away int,
  created_at timestamptz not null default now()
);

create table if not exists public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  content text not null,
  cover_image_url text,
  author text,
  published_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.gallery (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  caption text,
  category text,
  created_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  id uuid primary key default gen_random_uuid(),
  club_name text,
  description text,
  founded_year int,
  history text,
  mission text,
  contact_email text,
  contact_phone text,
  address text,
  facebook_url text,
  instagram_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.standings (
  id uuid primary key default gen_random_uuid(),
  team_name text not null,
  played int not null default 0,
  won int not null default 0,
  drawn int not null default 0,
  lost int not null default 0,
  goals_for int not null default 0,
  goals_against int not null default 0,
  points int not null default 0,
  is_own_team boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  video_url text not null,
  thumbnail_url text,
  description text,
  published_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

-- 2. ROW LEVEL SECURITY -------------------------------------------------
-- Public (anon) visitors can only READ. Only authenticated (logged-in staff)
-- users can INSERT / UPDATE / DELETE.

alter table public.players enable row level security;
alter table public.staff enable row level security;
alter table public.matches enable row level security;
alter table public.news enable row level security;
alter table public.gallery enable row level security;
alter table public.site_settings enable row level security;

do $$
declare
  t text;
begin
  for t in select unnest(array['players', 'staff', 'matches', 'news', 'gallery', 'site_settings', 'standings', 'videos'])
  loop
    execute format('drop policy if exists "public_read_%1$s" on public.%1$s', t);
    execute format('create policy "public_read_%1$s" on public.%1$s for select using (true)', t);

    execute format('drop policy if exists "auth_write_%1$s" on public.%1$s', t);
    execute format(
      'create policy "auth_write_%1$s" on public.%1$s for all using (auth.role() = ''authenticated'') with check (auth.role() = ''authenticated'')',
      t
    );
  end loop;
end $$;

-- 3. STORAGE -------------------------------------------------------------
-- Create a public "media" bucket for player photos, news covers, and gallery
-- images (Project > Storage > New bucket > name it "media", mark it Public),
-- or run this:

insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;

drop policy if exists "public_read_media" on storage.objects;
create policy "public_read_media" on storage.objects
  for select using (bucket_id = 'media');

drop policy if exists "auth_write_media" on storage.objects;
create policy "auth_write_media" on storage.objects
  for all using (bucket_id = 'media' and auth.role() = 'authenticated')
  with check (bucket_id = 'media' and auth.role() = 'authenticated');

-- 4. SEED SETTINGS ROW (edit and run once) -------------------------------

insert into public.site_settings (club_name, description, founded_year, history, mission, contact_email, contact_phone, address)
values (
  'FC Shpresa',
  'Akademi futbolli me dizajn modern, e themeluar mbi punën me brezat e rinj, disiplinën dhe dashurinë për lojën.',
  2008,
  'Shkruaj këtu historikun e akademisë: si u themelua, momentet kryesore, dhe rrugëtimin deri sot.',
  'Zhvillimi i lojtarëve të rinj përmes trajnimit profesional, vlerave sportive dhe edukimit.',
  'info@fcshpresa.al',
  '+355 6X XXX XXX',
  'Shkodër, Shqipëri'
)
on conflict do nothing;
